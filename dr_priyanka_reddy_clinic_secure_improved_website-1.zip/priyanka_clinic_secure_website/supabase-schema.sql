-- Supabase setup for database-backed appointment requests.
-- Run in Supabase SQL Editor after creating a project.
-- Review with a qualified developer before using with real patient data.

create extension if not exists pgcrypto;

create table if not exists public.clinic_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  full_name text not null check (char_length(full_name) between 2 and 80),
  phone text not null check (char_length(phone) between 7 and 18),
  preferred_date date not null,
  preferred_time text not null check (char_length(preferred_time) <= 40),
  language text not null default 'Telugu' check (language in ('Telugu','English')),
  short_note text not null default '' check (char_length(short_note) <= 250),
  status text not null default 'requested' check (status in ('requested','confirmed','completed','cancelled'))
);

alter table public.clinic_admins enable row level security;
alter table public.appointments enable row level security;

-- Only signed-in staff listed in clinic_admins may read/update requests.
create or replace function public.is_clinic_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.clinic_admins a
    where a.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_clinic_admin() from public;
grant execute on function public.is_clinic_admin() to anon, authenticated;

drop policy if exists "admin can read appointment requests" on public.appointments;
create policy "admin can read appointment requests"
on public.appointments for select to authenticated
using ((select public.is_clinic_admin()));

drop policy if exists "public can request appointment" on public.appointments;
create policy "public can request appointment"
on public.appointments for insert to anon, authenticated
with check (
  char_length(full_name) between 2 and 80
  and char_length(phone) between 7 and 18
  and preferred_date >= current_date
  and char_length(short_note) <= 250
  and status = 'requested'
);

drop policy if exists "admin can update appointment status" on public.appointments;
create policy "admin can update appointment status"
on public.appointments for update to authenticated
using ((select public.is_clinic_admin()))
with check ((select public.is_clinic_admin()));

-- Keep clinic_admins inaccessible to public users.
drop policy if exists "admins can view admin list" on public.clinic_admins;
create policy "admins can view admin list"
on public.clinic_admins for select to authenticated
using ((select public.is_clinic_admin()));

revoke all on public.appointments from anon, authenticated;
grant insert (full_name, phone, preferred_date, preferred_time, language, short_note, status)
  on public.appointments to anon, authenticated;
grant select on public.appointments to authenticated;
grant update (status) on public.appointments to authenticated;
revoke all on public.clinic_admins from anon, authenticated;
grant select on public.clinic_admins to authenticated;

-- IMPORTANT: after creating the staff user under Supabase Authentication > Users,
-- copy that user's UUID and run this statement with the real UUID:
-- insert into public.clinic_admins (user_id) values ('PASTE-STAFF-USER-UUID-HERE');
-- Never expose a service_role key in the website. Public inserts can attract spam;
-- add CAPTCHA/rate limiting, backups, access review, and applicable privacy compliance
-- before production. Do not store clinical notes or diagnoses in this simple request form.
